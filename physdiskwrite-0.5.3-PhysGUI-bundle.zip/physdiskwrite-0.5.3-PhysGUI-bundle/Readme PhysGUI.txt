Description of PhysGUI:

	PhysGUI is a graphical user interface for physdiskwrite.
	It offers a more detailed view of the available disks.
	Physdiskwrite must be present in the startup directory
	of PhysGUI.


PhysGUI was tested under the following operating systems:

	- Windows XP including SP3 and .Net Framework 3.5


Questions to:
	
	zweifelurs@gmail.com
	

Links:

	www.m0n0.ch

	
Thanks to:	
	
	Manuel Kasper for the quick adjustment of physdiskwrite

	
Note:

	USE ON YOUR OWN RISK!
